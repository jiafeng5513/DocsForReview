﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ParticleSwarmOptimizationDemo
{
    /// <summary>
    /// 粒子的结构
    /// </summary>
    class Posiotion
    {
        private double x;//x值,目标函数的X输入,该粒子的X坐标
        private double y;//y值,目标函数的X输入,该粒子的Y坐标
        private double f;//该点的函数值,f(x,y)

        public Posiotion(double x, double y)
        {
            this.X = x;
            this.Y = y;
        }

        public string toString()
        {
            return " x: " + x + " y: " + y + " f: " + f;
        }

        public double X { get => x; set => x = value; }
        public double Y { get => y; set => y = value; }
        public double F { get => f; set => f = value; }
    }
}
