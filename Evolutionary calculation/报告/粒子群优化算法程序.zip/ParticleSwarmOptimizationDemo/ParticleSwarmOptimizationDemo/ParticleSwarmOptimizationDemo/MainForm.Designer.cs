﻿namespace ParticleSwarmOptimizationDemo
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设置粒子数量ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设置迭代次数ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设置延迟ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_RunPSO = new System.Windows.Forms.ToolStripMenuItem();
            this.测试ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_DrawSinglePoint = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.文件ToolStripMenuItem,
            this.测试ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(704, 28);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 文件ToolStripMenuItem
            // 
            this.文件ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.设置粒子数量ToolStripMenuItem,
            this.设置迭代次数ToolStripMenuItem,
            this.设置延迟ToolStripMenuItem,
            this.MenuItem_RunPSO});
            this.文件ToolStripMenuItem.Name = "文件ToolStripMenuItem";
            this.文件ToolStripMenuItem.Size = new System.Drawing.Size(51, 24);
            this.文件ToolStripMenuItem.Text = "PSO";
            // 
            // 设置粒子数量ToolStripMenuItem
            // 
            this.设置粒子数量ToolStripMenuItem.Name = "设置粒子数量ToolStripMenuItem";
            this.设置粒子数量ToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.设置粒子数量ToolStripMenuItem.Text = "设置粒子数量";
            // 
            // 设置迭代次数ToolStripMenuItem
            // 
            this.设置迭代次数ToolStripMenuItem.Name = "设置迭代次数ToolStripMenuItem";
            this.设置迭代次数ToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.设置迭代次数ToolStripMenuItem.Text = "设置迭代次数";
            // 
            // 设置延迟ToolStripMenuItem
            // 
            this.设置延迟ToolStripMenuItem.Name = "设置延迟ToolStripMenuItem";
            this.设置延迟ToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.设置延迟ToolStripMenuItem.Text = "设置延迟";
            // 
            // MenuItem_RunPSO
            // 
            this.MenuItem_RunPSO.Name = "MenuItem_RunPSO";
            this.MenuItem_RunPSO.Size = new System.Drawing.Size(174, 26);
            this.MenuItem_RunPSO.Text = "开始求解";
            this.MenuItem_RunPSO.Click += new System.EventHandler(this.MenuItem_RunPSO_Click);
            // 
            // 测试ToolStripMenuItem
            // 
            this.测试ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItem_DrawSinglePoint});
            this.测试ToolStripMenuItem.Name = "测试ToolStripMenuItem";
            this.测试ToolStripMenuItem.Size = new System.Drawing.Size(51, 24);
            this.测试ToolStripMenuItem.Text = "测试";
            // 
            // MenuItem_DrawSinglePoint
            // 
            this.MenuItem_DrawSinglePoint.Name = "MenuItem_DrawSinglePoint";
            this.MenuItem_DrawSinglePoint.Size = new System.Drawing.Size(159, 26);
            this.MenuItem_DrawSinglePoint.Text = "绘制一个点";
            this.MenuItem_DrawSinglePoint.Click += new System.EventHandler(this.MenuItem_DrawSinglePoint_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(704, 592);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.Text = "粒子群算法";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.frmMain_Paint);
            this.Resize += new System.EventHandler(this.frmMain_Resize);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设置粒子数量ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设置迭代次数ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设置延迟ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_RunPSO;
        private System.Windows.Forms.ToolStripMenuItem 测试ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_DrawSinglePoint;
    }
}

