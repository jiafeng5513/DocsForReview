﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ParticleSwarmOptimizationDemo
{
    public partial class MainForm : Form
    {
        private const int NumOfParticles = 100;     //粒子个数
        private const int IterationTimes = 10000;   //迭代次数
        private const double MaxX = 60.0;           //函数的定义域
        private const double MaxY = 60.0;
        private const double W = 0.3;               //惯性权重
        private const double Vmax = 0.05;           //最大速度
        private const double C1 = 3;                //学习因子C1,个体经验权重
        private const double C2 = 1;                //学习因子C2,群体经验权重

        
        private List<Posiotion> _position;//第i个元素存储i号粒子的位置和适应函数值          
        private List<Posiotion> _velocity;//粒子的速度
        private List<Posiotion> _pbest;   //第i个元素代表i号粒子的历史最好情况
        private Posiotion _gbest;         //_gbest代表整个群体的最好情况

        private readonly GraphPainter _mGraphPainter = new GraphPainter();

        /// <summary>
        /// 目标函数,同时也是适应函数
        /// </summary>
        public void fitnessFunction()
        {//适应函数
            for (int i = 0; i < NumOfParticles; i++)
            {
                double x = _position[i].X;
                double y = _position[i].Y;
                if (x < 30 && y < 30)
                {
                    _position[i].F = (30 * x - y);
                }
                else if (x < 30 && y >= 30)
                {
                    _position[i].F = (30 * y - x);
                }
                else if (x >= 30 && y < 30)
                {
                    _position[i].F = (x * x - y / 2);
                }
                else if (x >= 30 && y >= 30)
                {
                    _position[i].F = (20 * y * y - 500 * x);
                }
            }
        }
        /// <summary>
        /// 初始化函数
        /// </summary>
        public void init()
        { //初始化
            _position = new List<Posiotion>(NumOfParticles);
            _velocity = new List<Posiotion>(NumOfParticles);
            _pbest = new List<Posiotion>(NumOfParticles);
            _gbest = new Posiotion(0.0, 0.0);
            /***
             * 初始化
             */
            Random rd = new Random();
            for (int i = 0; i < NumOfParticles; i++)
            {
                _position.Add( new Posiotion(rd.NextDouble() * MaxX, rd.NextDouble() * MaxY));
                _velocity.Add( new Posiotion(rd.NextDouble() * Vmax, rd.NextDouble() * Vmax));
            }
            fitnessFunction();
            //初始化当前个体极值，并找到群体极值
            _gbest.F = int.MinValue;
            for (int i = 0; i < NumOfParticles; i++)
            {
                _pbest.Add(_position[i]);  //position[i];
                if (_position[i].F > _gbest.F)
                {
                    _gbest = _position[i];
                    _gbest.F = (_position[i].F);
                }
            }
            Console.WriteLine("start gbest:" + _gbest.toString());
        }
        /// <summary>
        /// 运行算法
        /// </summary>
        /// <param name="max"></param>
        public void PSO_Method(int max)
        {
            Random rd = new Random();
            for (int i = 0; i < max; i++)
            {
                this.Refresh();
                for (int j = 0; j < NumOfParticles; j++)
                {
                    using (Graphics g = this.CreateGraphics())
                    {
                        _mGraphPainter.DrawSinglePoint(g, (float)_position[j].X, (float)_position[j].Y);
                    }
                }
                for (int j = 0; j < NumOfParticles; j++)
                {
                    //更新位置和速度
                    double vx = W * _velocity[j].X + C1 * rd.NextDouble() * (_pbest[j].X - _position[j].X) + C2 * rd.NextDouble() * (_gbest.X - _position[j].X);
                    double vy = W * _velocity[j].Y + C1 * rd.NextDouble() * (_pbest[j].Y - _position[j].Y) + C2 * rd.NextDouble() * (_gbest.Y - _position[j].Y);
                    if (vx > Vmax) vx = Vmax;
                    if (vy > Vmax) vy = Vmax;
                    //Console.WriteLine("======"+(i+1)+"======vx:"+vx);
                    _velocity[j] = new Posiotion(vx, vy);
                    //Console.WriteLine("======"+(i+1)+"======_velocity[j]:"+_velocity[j]);
                    _position[j].X = (_position[j].X + _velocity[j].X);
                    _position[j].Y = (_position[j].Y + _velocity[j].Y);
                    //越下界
                    if (_position[j].X <= 0) _position[j].X = (0.1);
                    if (_position[j].Y <= 0) _position[j].Y = (0.1);
                    //越上界
                    if (_position[j].X >= MaxX) _position[j].X = (MaxX-0.1);
                    if (_position[j].Y >= MaxY) _position[j].Y = (MaxY-0.1); 
                }
                fitnessFunction();
                //更新个体极值和群体极值
                for (int j = 0; j < NumOfParticles; j++)
                {
                    if (_pbest[j].F < _position[j].F)
                    {
                        _pbest[j] = _position[j];
                    }
                    if (_position[j].F > _gbest.F)
                    {
                        _gbest = _position[j];
                        _gbest.F = (_position[j].F);
                    }
                }
                Console.WriteLine("======" + (i + 1) + "======gbest:" + _gbest.toString());
            }
        }
        public MainForm()
        {
            InitializeComponent();

            using (Graphics g = this.CreateGraphics())
            {
                _mGraphPainter.InitGraphPositions(g, this.ClientSize);
            }

            this.DoubleBuffered = true;
        }
        /// <summary>
        /// 画坐标系
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmMain_Paint(object sender, PaintEventArgs e)
        {
            _mGraphPainter.DrawCoordinate(e.Graphics, this.ClientSize);
        }
        /// <summary>
        /// 重绘,只考虑了坐标轴
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmMain_Resize(object sender, EventArgs e)
        {
            using (Graphics g = this.CreateGraphics())
            {
                _mGraphPainter.InitGraphPositions(g, this.ClientSize);
            }
            this.Refresh();
        }
        /// <summary>
        /// 菜单->测试->绘制一个单点,坐标值是理想坐标系
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItem_DrawSinglePoint_Click(object sender, EventArgs e)
        {

            using (Graphics g = this.CreateGraphics())
            {
                _mGraphPainter.DrawSinglePoint(g, 20,20);
            }
            //this.Refresh();
        }
        /// <summary>
        /// 菜单->PSO->运行算法
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItem_RunPSO_Click(object sender, EventArgs e)
        {
            init();
            PSO_Method(IterationTimes);
        }
    }
}
